package com.example.finlalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Main2Activity extends AppCompatActivity {

    private EditText tv3, tv4, tv5;
    private Button signup1, login1;
    private TextView userid, password, email;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        setUIViews();

        firebaseAuth = FirebaseAuth.getInstance();
        signup1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (validate()){
                    //Upload data to the data base
                    String user_email = tv5.getText().toString().trim();
                    String user_password = tv4.getText().toString().trim();

                    firebaseAuth.createUserWithEmailAndPassword(user_email, user_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful()) {
                                Toast.makeText(Main2Activity.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(Main2Activity.this, MainActivity.class));
                            } else {
                                Toast.makeText(Main2Activity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }) ;
                };
            }
        });

        login1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Main2Activity.this, MainActivity.class));
            }
        });

    }
    private void setUIViews(){
        tv3 = (EditText)findViewById(R.id.tv3);
        tv4 = (EditText)findViewById(R.id.tv4);
        tv5 = (EditText)findViewById(R.id.tv5);
        signup1 = (Button) findViewById(R.id.signup1);
        login1 = (Button)findViewById(R.id.login1);
        userid = (TextView) findViewById(R.id.userid);
        password = (TextView) findViewById(R.id.password);
        email = (TextView) findViewById(R.id.email);

    }

    private Boolean validate(){
        Boolean result = false;

        String userid = tv3.getText().toString();
        String password = tv4.getText().toString();
        String email = tv5.getText().toString();

        if(userid.isEmpty() || password.isEmpty() || email.isEmpty()) {
            Toast.makeText(this, "Please fill all details", Toast.LENGTH_SHORT).show();
        }
        else{
            result = true;
        }
        return result;
    }
}
