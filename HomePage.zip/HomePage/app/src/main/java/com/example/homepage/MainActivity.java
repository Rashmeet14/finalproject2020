package com.example.homepage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    RecyclerView mRecyclerView;
    Myadapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_main);

        mRecyclerView = findViewById(R.id.recyclerview);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        myAdapter = new Myadapter(this, getMyList());
        mRecyclerView.setAdapter(myAdapter);
    }

    private ArrayList<Model> getMyList() {
        ArrayList<Model> models = new ArrayList<>();
        Model m = new Model();
        m.setTittle("Liquids");
        m.setImg(R.drawable.download);
        m.setDescription("Here are some fresh liquids for yummy and delicious food");

        models.add(m);

        m = new Model();
        m.setTittle("Herbs");
        m.setImg(R.drawable.hrbs);
        m.setDescription("Here are some fresh herbs which enhance the taste of food");

        models.add(m);

        m = new Model();
        m.setTittle("Grains");
        m.setImg(R.drawable.grains);
        m.setDescription("Here are some fresh grains blend with the pureest form ");

        models.add(m);


        m = new Model();
        m.setTittle("Toppings");
        m.setImg(R.drawable.toppings);
        m.setDescription("Here are the toppings , gives the natural taste with every bite");

        models.add(m);
        return models;

    }

}

