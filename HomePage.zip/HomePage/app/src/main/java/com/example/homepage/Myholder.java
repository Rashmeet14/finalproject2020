package com.example.homepage;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

  public class Myholder extends RecyclerView.ViewHolder {

       ImageView mImaeView;
      TextView mTittle;
      TextView mDes;


      public Myholder(@NonNull View itemView) {
          super(itemView);
      this.mImaeView=itemView.findViewById(R.id.ImageIv);
          this.mTittle=itemView.findViewById(R.id.tittletv);
          this.mDes=itemView.findViewById(R.id.ImageIv);


      }
  }
