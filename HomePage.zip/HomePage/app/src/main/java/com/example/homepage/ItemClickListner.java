package com.example.homepage;

import android.view.View;

public interface ItemClickListner {

    void onItemClickListner(View v,int postion)






}
